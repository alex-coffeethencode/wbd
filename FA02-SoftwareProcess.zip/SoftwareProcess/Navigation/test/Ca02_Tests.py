
import unittest
import Navigation.prod.Fix as Fix
import math


#20 min of test code writing with ~= 2 hours prep

#coding 1154 10/10

class Ca02_Test(unittest.TestCase):

    def setUp(self):
        pass
    def tearDown(self):
        pass

#Individual Box Testing:

#m1 =  Fix() (The constructor)
    #Assert Valid contructor
    def test100_010_ShouldConstruct(self):
        self.assertIsInstance(Fix.Fix(), Fix.Fix)

    def test100_020_TestEmptyInput___ShouldCreateOutputDotText(self):
        myFix = Fix.Fix()
        self.assertEquals(myFix.logFile, "output.txt")
        #Need to assert that output.txt is created
        
    def test100_030_TestBadInput(self):
        expectedString = "Fix.Fix:"
        #Should be value errror:
        with self.assertRaises(ValueError) as context:   
            myFix = Fix.Fix("")
        self.assertEquals(expectedString, context.exception.args[0][0:len(expectedString)])
    
    def test100_040_UnAppendableFile(self):
        expectedString = "Fix.Fix:"
        
        with self.assertRaises(ValueError) as context:   
            myFix = Fix.Fix("thisDoesntExistYet.txt")
        self.assertEquals(expectedString, context.exception.args[0][0:len(expectedString)])
    
    def test100_050_LegalFile(self):
        filename = "myLogFile.txt"
        myFix = Fix.Fix(filename)
        self.assertEquals(myFix.logFile, filename)
#m2 = setSightingFile

    # Cut from testing
   # def test200_010_EmptyInput(self):
    #    expectedString = "Fix.setSightingFile:"
    #    myFix = Fix.Fix("text.txt")
    #    #Should be value error:
    #    with self.assertRaises(ValueError) as context:   
    #        myFix.setSightingFile()
    #    self.assertEquals(expectedString, context.exception.args[0][0:len(expectedString)])
    
    def test200_020_BadExtension(self):
        expectedString = "Fix.setSightingFile:"
        myFix = Fix.Fix("text.txt")
        
        with self.assertRaises(ValueError) as context:   
            myFix.setSightingFile("badExtension.txt")
        self.assertEquals(expectedString, context.exception.args[0][0:len(expectedString)])
    
    def test200_030_BadFilename_Good_Extension(self):
        expectedString = "Fix.setSightingFile:"
        myFix = Fix.Fix("text.txt")
        
        with self.assertRaises(ValueError) as context:   
            myFix.setSightingFile(".xml")
        self.assertEquals(expectedString, context.exception.args[0][0:len(expectedString)])
    
    # Cut from testing
    #def test200_040_CannotAppend(self):
    #    expectedString = "Fix.setSightingFile:"
    #    myFix = Fix.Fix("text.txt")
    #    
    #    with self.assertRaises(ValueError) as context:   
    #        myFix.setSightingFile("unAppendable.xml")
    #    self.assertEquals(expectedString, context.exception.args[0][0:len(expectedString)])
    
    
    def test200_050_CanAppend(self):
        expectedString = "Fix.setSightingFile:"
        myFix = Fix.Fix("text.txt")
        myFix.setSightingFile("f.xml")
        
        self.assertEquals(myFix.sightFile, "f.xml")
        
    
    
 #   def test300_001_BadTestingPractice(self):
 #       myFix = Fix.Fix("myLogFile.txt")
 #       myFix.setSightingFile("f.xml")
 #       approxPos = myFix.getSightings()
        #No real test, trying ot confirm working without "run"
        
        
    def test300_010_F2_EmptyNoSighting(self):
        expectedString = "Fix.getSightings:"
        myFix = Fix.Fix("text.txt")
        
        with self.assertRaises(ValueError) as context:   
            myFix.setSightingFile("f2.xml")
            myFix.getSightings()
        self.assertEquals(expectedString, context.exception.args[0][0:len(expectedString)])
    
    
    def test300_020_F3_BadVarAsTag(self):
        expectedString = "Fix.setSightingFile:"
        myFix = Fix.Fix("text.txt")
        
        with self.assertRaises(ValueError) as context:   
            myFix.setSightingFile("f3.xml")
            myFix.getSightings()
        self.assertEquals(expectedString, context.exception.args[0][0:len(expectedString)])
    
    
    def test300_030_F4_MissingTempInSecond(self):
        expectedString = "Fix.setSightingFile:"
        myFix = Fix.Fix("text.txt")
        
        with self.assertRaises(ValueError) as context:   
            myFix.setSightingFile("f4.xml")
            myFix.getSightings()
        self.assertEquals(expectedString, context.exception.args[0][0:len(expectedString)])
    
    
    def test300_040_F5_Missing2ndObservationRequired(self):
        expectedString = "Fix.setSightingFile:"
        myFix = Fix.Fix("text.txt")
    
        with self.assertRaises(ValueError) as context:   
            myFix.setSightingFile("f5.xml")
            myFix.getSightings()
        self.assertEquals(expectedString, context.exception.args[0][0:len(expectedString)])
    
    
    def test300_050_F6_LeadingWhiteSpace(self):
        expectedString = "Fix.setSightingFile:"
        myFix = Fix.Fix("text.txt")
    
        with self.assertRaises(ValueError) as context:   
            myFix.setSightingFile("f6.xml")
            myFix.getSightings()
        self.assertEquals(expectedString, context.exception.args[0][0:len(expectedString)])
    
    # LSF = LegalSi
    #def test300_060_LegalSightingFile(self):
    #    expectedString = "Fix.setSightingFile:"
     #   myFix = Fix.Fix("myLogFile.txt")
#
 #       myFix.setSightingFile("f.xml")
  #      asdf = myFix.getSightings()
           
   #     myLog = open("myLogFile.txt", "r")
    #    firstLine = ""
     #   self.assertEqual(myLog[0], firstLine)
        
    
    
    