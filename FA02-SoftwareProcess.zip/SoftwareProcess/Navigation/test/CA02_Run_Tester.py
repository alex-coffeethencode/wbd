
import Navigation.prod.Angle as Angle
import Navigation.prod.Fix as Fix
import Navigation.prod.Sighting as Sighting

#from Navigation.prod.Angle import Angle
#from lib2to3.pgen2.tokenize import String
def main():
    myFix = Fix.Fix("myLogFile.txt")
    myFix.setSightingFile("f.xml")

    print("Start")
    approxPos = myFix.getSightings()
    print("End")


main()