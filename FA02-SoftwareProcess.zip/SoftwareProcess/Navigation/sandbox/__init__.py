''' 
    Created to run Test. 
        Instead of properly sandboxing code, I just wrote tests  
    
    Baselined: Sept 4th, 2016 
    Modified: Sept 11th 2016
    @author:    Alex Schultz
 
''' 

import test
from Navigation.test import MyTester

from Navigation.test import customerTrialRun
from Navigation.test import modCustomerTrialRun

def main():
    MyTester()
    
    #modCustomerTrialRun()
    #customerTrialRun()
    #Done

main()
