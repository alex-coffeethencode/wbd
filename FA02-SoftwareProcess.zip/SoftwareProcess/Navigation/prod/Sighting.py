
class Sighting():
    
    def __init__(self):
        pass
    
    def confirmRequired(self):
        return False