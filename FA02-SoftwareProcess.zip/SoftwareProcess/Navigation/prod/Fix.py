'''
Created on Oct 10, 2016

@author: Alex
'''


# is Sighting mandatory?

import math
#from xml.dom.minidom import parse, parseString
from lib2to3.fixer_util import String
import Navigation.prod.Angle as Angle
import os.path
import xml.dom.minidom


#coding 1154 10/10
#        1215


class Fix():
    
    logFile = ""
    sightFile = None
    
    def __init__(self, fileIn = "output.txt"):
        try:
            cwd = os.getcwd() 
            
    
            if fileIn == "output.txt":
                self.logFile = fileIn
                #return self
            elif len(fileIn) < 1:
                raise ValueError("Fix.Fix:  Filename length GE 1")
            elif os.path.isfile(cwd + os.path.sep + fileIn):
                self.logFile = fileIn
            else:
              raise ValueError("Fix.Fix:  File not found")
            #with open(self.logFile, "a") as file:
            #        file.write("Hello World")
        except:
             raise ValueError("Fix.Fix:  Error Found")
     
    def setSightingFile(self, sightingFile):
   #     try:
        if sightingFile == None:
            raise ValueError("Fix.setSightingFile:  File not passed")
        
        cwd = os.getcwd() 
       # print(cwd + os.path.sep + sightingFile)

        #check for valid extension and ensures .xml is not a valid name
        if sightingFile.find(".xml") > 0:
            
            if not os.path.isfile(cwd + os.path.sep + sightingFile):
                raise ValueError("Fix.setSightingFile:  File not found")
            
            
            self.sightFile = sightingFile
            
            return True #self.checkIfFileExistsInLog()
            
        else:
            raise ValueError("Fix.setSightingFile:  File has invalid extension or not enough characters")
            
 #       except:
  #           raise ValueError("Fix.setSightingFile:   Error Found")

    
    
        # This set retruns Aldebaren
        #openedLog = open(self.sightFile)
        #myDom = xml.dom.minidom.parse(openedLog)
        #mySight = myDom.getElementsByTagName("sighting")[0]
        #myBody = mySight.getElementsByTagName("body")[0]
        # print "%s" % (getText(myBody.childNodes))
        
     
    def getSightings(self):
        obsveredAlt = 0.1
        
        if self.sightFile == None:
            return False
                #raise ValueError("Fix.getSightings:  File not set")
    
        openedFile = open(self.sightFile)
        myDom = xml.dom.minidom.parse(openedFile)
        openedFile.close()

        mySight = myDom.getElementsByTagName("sighting")     # doc
        myArray = getSightingList(mySight)
        openedLog = open(self.logFile, "a")
        
        if type(myArray) == ValueError:
            openedLog.write("End of sighting file " + self.sightFile)
            openedFile.close()
            raise myArray
          
        elif myArray == False:
            return False
        
        else:
            for log in myArray:
                openedLog.write(log + "\n")
            
            #print (getTExt(var + "\n")
         
        #print(myDom.getElementsByTagName("Fix")[0])
        openedLog.write("End of sighting file " + self.sightFile)
                        
        latitude = "0d0.0"
        longitude = "odo.o"
        return (latitude, longitude)

    
    
    
    
    # ffunc name + writes file to log if no already there
    def checkIfFileExistsInLog(self):
        openedLog = open(self.logFile, "r+")
        startLine = "Start of sighting file " + self.sightFile
        
        
        for line in openedLog:
            if startLine in line:
                return False
            
        openedLog.close()
        # Line not found,append to log
        openedLog = open(self.logFile, "a+")
        openedLog.write(startLine + "\n")
        openedLog.close()
        return True
    
    #?
    # NEED TO CLARIFY FULL CITATION

#FROM:
#https://docs.python.org/2/library/xml.dom.minidom.html#dom-objects
        
def getText(nodelist):
    rc = []
    for node in nodelist:
        if node.nodeType == node.TEXT_NODE:
            rc.append(node.data)
    return ''.join(rc)


# My Additonal  MEthods:
def calcAdjAlt(optAct, obsAlt):
    try:
        myAngle = Angle.Angle()
        myAngle.setDegreesAndMinutes(obsAlt)
        
        dip = 0
        if optAct[3] == "Natural":
            dip = (-0.97 * math.sqrt(optAct[0]))/60 
        
        refraction = (-0.00452 * float(optAct[2])) / (273 + float(optAct[1])) / math.tan(myAngle.getDegrees())
        #absAlt = Angle
        #Angle Comparison:
        
        
        myAngle.add(Angle.Angle().setDegrees(dip + refraction))
    
        if myAngle.getDegrees() < 0.1:
            return ValueError("Fix.setSightingFile:  Must be greater than 0.1")
             
        return myAngle.getString()
    except:
        return ValueError("Fix.setSightingFile:  CalcAdjAltError")
        


def createLogEntry(reqAct, optAct):
    log = reqAct[0] + "\t" + reqAct[1] + "\t" +  reqAct[2] + "\t"
    adjAlt = calcAdjAlt(optAct, reqAct[3])
    
    if type(adjAlt) == ValueError:
        return adjAlt
    
    log = log + str(adjAlt)
    return log


    # opt = optional
    # req = required
    # Act = Actual
    
def getSightingList(mySight):
    # Sort by date then time then body
    
    # Assumes sighting is mandatory
    if len(mySight) == 0:
        return ValueError("Fix.getSightings:  no sightings found")
            
    sightingList = []

    requiredVar = ["body", "date", "time", "observation"]
    optionalVar = ["height", "temperature", "pressure", "horizon"]
    
    size = len(mySight)
    
    for ctr in range (0,size):
        
        reqAct = ["","","",""]
        # setDefualts
        optAct = [0,72,1010,"Natural"]
        
        for reqVar in requiredVar:
            var = mySight[ctr].getElementsByTagName(reqVar)                #doc
            if len(var) >= 0:
                # parse for whitespace
                reqAct[requiredVar.index(reqVar)] = getText(var[0].childNodes)
            else:
                return ValueError("Fix.getSightings:  REquired element not in sighting")
                
        for optVar in optionalVar:
            var = mySight[ctr].getElementsByTagName(optVar)                #doc
            if len(var) >= 0:
                optAct[optionalVar.index(optVar)] = getText(var[0].childNodes)

        # Check req val filled in
        for required in reqAct:
            if required == "":
                return ValueError("Fix.setSightingFile:  File has invalid extension or not enough characters")
        
        # Just for assurance:
        if optAct[3] != "Natural": 
            if optAct[3] != "Artificial" :
                print optAct[3]
                return ValueError("Fix.setSightingFile:  Horizen must either natural or artificial")
        
    
        
        # presuming all reqAct are filled out:
        #    Create log entry
        
        entry = createLogEntry(reqAct, optAct) 

        if type(entry) == ValueError:
            return entry

        sightingList.append(entry)
    return sightingList    
